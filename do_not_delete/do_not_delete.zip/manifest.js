FT.manifest({
    "filename": "index.html",
    "width": 300,
    "height": 250,
    "clickTagCount": 0,
    "hideBrowsers": ["ie8"],
    "richLoads": [
        { "name": "Main_RL","src": "image_font_cdn_rl" }
    ],
	"instantAds": [
			{"name": "Main_RL", "type": "richload", "default": "mailchimp_fonts_rl"},
			{"name":"image1",   "type":"image", "default":"images/blank.png"},
			{"name":"image2",   "type":"image", "default":"images/blank.png"},
			{"name":"image3",   "type":"image", "default":"images/blank.png"},
			{"name":"image4",   "type":"image", "default":"images/blank.png"},
			{"name":"image5",   "type":"image", "default":"images/blank.png"},
			{"name":"image6",   "type":"image", "default":"images/blank.png"}
		]
});